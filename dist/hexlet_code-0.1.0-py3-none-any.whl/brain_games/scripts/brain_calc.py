import random


DESCRIPTION = 'What is the result of the expression?'


def Question():
    RandomNumberFirst1 = random.randint(1, 10)
    RandomNumberFirst2 = random.randint(1, 10)
    Operation = random.choice(['-', '+', '*'])
    RightAnswer = ''
    if Operation == '-':
        RightAnswer = RandomNumberFirst1 - RandomNumberFirst2
    elif Operation == '+':
        RightAnswer = RandomNumberFirst1 + RandomNumberFirst2
    elif Operation == '*':
        RightAnswer = RandomNumberFirst1 * RandomNumberFirst2
    question = f'{RandomNumberFirst1} {Operation} {RandomNumberFirst2}'
    return RightAnswer, Question


if __name__ == '__main__':
    Question()
