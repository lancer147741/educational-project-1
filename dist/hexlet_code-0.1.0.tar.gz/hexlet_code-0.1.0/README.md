### Hexlet tests and linter status:
[![Actions Status](https://github.com/lancer147741/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/lancer147741/python-project-49/actions) [![Maintainability](https://api.codeclimate.com/v1/badges/cc8168d042c68178ff26/maintainability)](https://codeclimate.com/github/lancer147741/python-project-49/maintainability)
### Asciinema brain-even:
[![asciicast](https://asciinema.org/a/PepkTTkjwZMUb4DiE3HCZdcOM.svg)](https://asciinema.org/a/PepkTTkjwZMUb4DiE3HCZdcOM)
### Asciinema brain-calc:
[![asciicast](https://asciinema.org/a/TqUNjktYA2t0vRDSJRjhobFO8.svg)](https://asciinema.org/a/TqUNjktYA2t0vRDSJRjhobFO8)
### Asciinema brain-gcd:
[![asciicast](https://asciinema.org/a/P1axCyIrefJcGhMyNubg57Veb.svg)](https://asciinema.org/a/P1axCyIrefJcGhMyNubg57Veb)