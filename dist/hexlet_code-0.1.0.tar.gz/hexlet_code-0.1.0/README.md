### Hexlet tests and linter status:
[![Actions Status](https://github.com/lancer147741/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/lancer147741/python-project-49/actions)
### Asciinema brain-even:
[![asciicast](https://asciinema.org/a/PepkTTkjwZMUb4DiE3HCZdcOM.svg)](https://asciinema.org/a/PepkTTkjwZMUb4DiE3HCZdcOM)
